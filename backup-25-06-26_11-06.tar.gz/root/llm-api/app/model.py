from transformers import pipeline

def get_generator():
    return pipeline("text-generation", model="gpt2")

