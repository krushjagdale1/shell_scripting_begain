from fastapi import FastAPI, Request
from app.model import get_generator

app = FastAPI()
generator = get_generator()

@app.post("/generate")
async def generate(request: Request):
    data = await request.json()
    prompt = data.get("prompt", "")
    result = generator(prompt, max_length=50)[0]["generated_text"]
    return {"result": result}
